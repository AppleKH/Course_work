package course.work.gamequiz;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Random;

public class Level5 extends AppCompatActivity {

    Dialog dialog;
    Dialog dialogEnd;

    public int numLeft; //переменная для левой картинки + текст
    public int numRight; //переменная для правой картинки + текст
    Array array = new Array(); //создали новый объект из класса Array
    Random random = new Random(); //для генерации случайных чисел
    public int count = 0; //счетчик правильных ответов


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.universal);

        //создаем переменную text_levels
        TextView text_levels = findViewById(R.id.text_levels);
        text_levels.setText(R.string.level5); //установили текст

        final ImageView img_left = (ImageView)findViewById(R.id.img_left);
        //код, который скругляет углы левой картинки
        img_left.setClipToOutline(true);

        final ImageView img_right = (ImageView)findViewById(R.id.img_right);
        //код, который скругляет углы правой картинки
        img_right.setClipToOutline(true);

        //путь к левой TextView
        final TextView text_left = findViewById(R.id.text_left);
        //путь к правой TextView
        final TextView text_right = findViewById(R.id.text_right);

        //развернуть игру на весь экран - начало
        Window w = getWindow();
        w.setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
        //развернуть игру на весь экран - конец

        //устанавливаем фон - начало
        ImageView background = (ImageView)findViewById(R.id.background);
        background.setImageResource(R.drawable.level5);
        //устанавливаем фон - конец

        //вызов диалогового окна в начале игры
        dialog = new Dialog(this); //создаем новое диалоговое окно
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE); //скрываем заголовок
        dialog.setContentView(R.layout.previewdialog); //путь к макету диалогового окна
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT)); //прозрачный фон диалогового окна
        dialog.setCancelable(false); //окно нельзя закрыть кнопкой "Назад"

        //устанавливаем картинку в диалоговое окно - начало
        ImageView previewimg = (ImageView)dialog.findViewById(R.id.previewimg);
        previewimg.setImageResource(R.drawable.previewimg5);
        //устанавливаем картинку в диалоговое окно - конец

        //устанавливаем фон для диалогового окна - начало
        LinearLayout dialogfon = (LinearLayout)dialog.findViewById(R.id.dialogfon);
        dialogfon.setBackgroundResource(R.drawable.previewbackground5);
        //устанавливаем фон для диалогового окна - конец

        //устанавливаем описание задание - начало
        TextView textdescription = (TextView)dialog.findViewById(R.id.textdescription);
        textdescription.setText(R.string.levelfive);
        //устанавливаем описание задание - конец

        //кнопка, которая закрывает диалоговое окно - начало
        TextView btnclose = (TextView)dialog.findViewById(R.id.btnclose);
        btnclose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //обрабатываем нажатие кнопки - начало
                try {
                    //вернуться назад к выбору уровня - начало
                    Intent intent = new Intent(Level5.this, GameLevels.class); //создали намерение для перехода на страницу с уровнями
                    startActivity(intent);finish();
                    //вернуться назад к выбору уровня - конец
                }catch (Exception e){}
                dialog.dismiss();
                //обрабатываем нажатие кнопки - конец
            }
        });
        //кнопка, которая закрывает диалоговое окно - конец

        //кнопка "Продолжить" - начало
        Button btncontinue = (Button)dialog.findViewById(R.id.btncontinue);
        btncontinue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        //кнопка "Продолжить" - конец

        dialog.show();

        //____________________
        //вызов диалогового окна в конце игры
        dialogEnd = new Dialog(this); //создаем новое диалоговое окно
        dialogEnd.requestWindowFeature(Window.FEATURE_NO_TITLE); //скрываем заголовок
        dialogEnd.setContentView(R.layout.dialogend); //путь к макету диалогового окна
        dialogEnd.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT)); //прозрачный фон диалогового окна
        dialogEnd.getWindow().setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
        dialogEnd.setCancelable(false); //окно нельзя закрыть кнопкой "Назад"

        //устанавливаем фон диалогового окна - начало
        LinearLayout dialogfonEnd = (LinearLayout)dialogEnd.findViewById(R.id.dialogfon);
        dialogfonEnd.setBackgroundResource(R.drawable.previewbackground5);
        //устанавливаем фон диалогового окна - конец


        //текст на прохождение уровня - начало
        TextView textdescriptionEnd = (TextView)dialogEnd.findViewById(R.id.textdescriptionEnd);
        textdescriptionEnd.setText(R.string.levelEnd);
        //текст на прохождение уровня - конец

        //кнопка, которая закрывает диалоговое окно - начало
        TextView btnclose2 = (TextView)dialogEnd.findViewById(R.id.btnclose);
        btnclose2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //обрабатываем нажатие кнопки - начало
                try {
                    //вернуться назад к выбору уровня - начало
                    Intent intent = new Intent(Level5.this, GameLevels.class); //создали намерение для перехода на страницу с уровнями
                    startActivity(intent);finish();
                    //вернуться назад к выбору уровня - конец
                }catch (Exception e){}
                dialogEnd.dismiss();
                //обрабатываем нажатие кнопки - конец
            }
        });
        //кнопка, которая закрывает диалоговое окно - конец

        //кнопка "Продолжить" - начало
        Button btncontinue2 = (Button)dialogEnd.findViewById(R.id.btncontinue);
        btncontinue2.setText(R.string.textback);
        btncontinue2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    Intent intent = new Intent(Level5.this, GameLevels.class);
                    startActivity(intent);finish();
                }catch (Exception e){

                }
                dialogEnd.dismiss();
            }
        });
        //кнопка "Продолжить" - конец

        //____________________

        //кнопка "Назад" - начало
        Button btn_back = (Button) findViewById(R.id.button_back);
        btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    //вернуться назад к выбору уровня - начало
                    Intent intent = new Intent(Level5.this, GameLevels.class); //возвращаемся на страницу с уровнями
                    startActivity(intent);finish();
                    //вернуться назад к выбору уровня - конец
                }catch (Exception e){}
            }
        });
        //кнопка "Назад" - конец

        //массив для прогресса игры - начало
        final int[] progress = {
                R.id.point1, R.id.point2, R.id.point3, R.id.point4, R.id.point5,
                R.id.point6, R.id.point7, R.id.point8, R.id.point9, R.id.point10,
                R.id.point11, R.id.point12, R.id.point13, R.id.point14, R.id.point15,
                R.id.point16, R.id.point17, R.id.point18, R.id.point19, R.id.point20,
        };

        //массив для прогресса игры - конец


        //подключаем анимацию - начало
        final Animation a = AnimationUtils.loadAnimation(Level5.this, R.anim.alpha);
        //подключаем анимацию - конец


        numLeft = random.nextInt(8); //генерируем случайное число
        img_left.setImageResource(array.images5[numLeft]); //достаем из массива картинку
        text_left.setText(array.text5[numLeft]); //достаем из массива текст

        numRight = random.nextInt(8); //генерируем случайное число

        //цикл с предусловием, проверяющее равенство чисел - начало
        while (numLeft==numRight){
            numRight = random.nextInt(8);
        }
        //цикл с предусловием, проверяющее равенство чисел - конец

        img_right.setImageResource(array.images5[numRight]);
        text_right.setText(array.text5[numRight]);

        //обрабатываем нажатие на левую картинку - начало
        img_left.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                //условие касание картинки - начало
                if (event.getAction()==MotionEvent.ACTION_DOWN) {
                    //если коснулся картинки
                    img_right.setEnabled(false); //блокируем правую картинку
                    if (numLeft>numRight){
                        img_left.setImageResource(R.drawable.img_true);
                    }else{
                        img_left.setImageResource(R.drawable.img_false);
                    }
                }else if (event.getAction()==MotionEvent.ACTION_UP){
                    //если опустил палец с картинки
                    if(numLeft>numRight){
                        //если левая картинка больше
                        if(count<20){
                            count=count+1;
                        }
                        //закрашиваем прогресс серым цветом
                            for (int i=0; i<20; i++){
                                TextView tv = findViewById(progress[i]);
                                tv.setBackgroundResource(R.drawable.style_points);
                            }
                        //определяем правильный ответ и закрашиваем зеленым
                            for(int i=0; i<count; i++){
                                TextView tv = findViewById(progress[i]);
                                tv.setBackgroundResource(R.drawable.style_points_green);
                            }
                    }else{
                        //если левая картинка меньше
                        if(count>0){
                            if(count==1){
                                count=0;
                            }else{
                                count=count-2;
                            }
                        }
                        //закрашиваем прогресс серым цветом
                        for (int i=0; i<19; i++){
                            TextView tv = findViewById(progress[i]);
                            tv.setBackgroundResource(R.drawable.style_points);
                        }
                        //определяем правильный ответ и закрашиваем зеленым
                        for(int i=0; i<count; i++){
                            TextView tv = findViewById(progress[i]);
                            tv.setBackgroundResource(R.drawable.style_points_green);
                        }
                    }
                        if(count==20){
                            //выход из уровня
                            dialogEnd.show();
                        }else{
                            numLeft = random.nextInt(8); //генерируем случайное число
                            img_left.setImageResource(array.images5[numLeft]); //достаем из массива картинку
                            img_left.startAnimation(a);
                            text_left.setText(array.text5[numLeft]); //достаем из массива текст

                            numRight = random.nextInt(8); //генерируем случайное число

                            //цикл с предусловием, проверяющее равенство чисел - начало
                            while (numLeft==numRight){
                                numRight = random.nextInt(8);
                            }
                            //цикл с предусловием, проверяющее равенство чисел - конец

                            img_right.setImageResource(array.images5[numRight]);
                            img_right.startAnimation(a);
                            text_right.setText(array.text5[numRight]);

                            img_right.setEnabled(true); //включаем обратно правую картинку
                        }
                }
                //условие касание картинки - конец
                return true;
            }
        });
        //обрабатываем нажатие на левую картинку - конец

        //обрабатываем нажатие на правую картинку - начало
        img_right.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                //условие касание картинки - начало
                if (event.getAction()==MotionEvent.ACTION_DOWN) {
                    //если коснулся картинки
                    img_left.setEnabled(false); //блокируем левую картинку
                    if (numLeft<numRight){
                        img_right.setImageResource(R.drawable.img_true);
                    }else{
                        img_right.setImageResource(R.drawable.img_false);
                    }
                }else if (event.getAction()==MotionEvent.ACTION_UP){
                    //если опустил палец с картинки
                    if(numLeft<numRight){
                        //если правая картинка больше
                        if(count<20){
                            count=count+1;
                        }
                        //закрашиваем прогресс серым цветом
                        for (int i=0; i<20; i++){
                            TextView tv = findViewById(progress[i]);
                            tv.setBackgroundResource(R.drawable.style_points);
                        }
                        //определяем правильный ответ и закрашиваем зеленым
                        for(int i=0; i<count; i++){
                            TextView tv = findViewById(progress[i]);
                            tv.setBackgroundResource(R.drawable.style_points_green);
                        }
                    }else{
                        //если правая картинка меньше
                        if(count>0){
                            if(count==1){
                                count=0;
                            }else{
                                count=count-2;
                            }
                        }
                        //закрашиваем прогресс серым цветом
                        for (int i=0; i<19; i++){
                            TextView tv = findViewById(progress[i]);
                            tv.setBackgroundResource(R.drawable.style_points);
                        }
                        //определяем правильный ответ и закрашиваем зеленым
                        for(int i=0; i<count; i++){
                            TextView tv = findViewById(progress[i]);
                            tv.setBackgroundResource(R.drawable.style_points_green);
                        }
                    }
                    if(count==20){
                        //выход из уровня
                        dialogEnd.show();
                    }else{
                        numLeft = random.nextInt(8); //генерируем случайное число
                        img_left.setImageResource(array.images5[numLeft]); //достаем из массива картинку
                        img_left.startAnimation(a);
                        text_left.setText(array.text5[numLeft]); //достаем из массива текст

                        numRight = random.nextInt(8); //генерируем случайное число

                        //цикл с предусловием, проверяющее равенство чисел - начало
                        while (numLeft==numRight){
                            numRight = random.nextInt(8);
                        }
                        //цикл с предусловием, проверяющее равенство чисел - конец

                        img_right.setImageResource(array.images5[numRight]);
                        img_right.startAnimation(a);
                        text_right.setText(array.text5[numRight]);

                        img_left.setEnabled(true); //включаем обратно левую картинку
                    }
                }
                //условие касание картинки - конец
                return true;
            }
        });
        //обрабатываем нажатие на правую картинку - конец

    }

    //системная кнопка "Назад" - начало
    @Override
    public void onBackPressed(){
        try {
            //вернуться назад к выбору уровня - начало
            Intent intent = new Intent(Level5.this, GameLevels.class); //возвращаемся на страницу с уровнями
            startActivity(intent);finish();
            //вернуться назад к выбору уровня - конец
        }catch (Exception e){}
    }
    //системная кнопка "Назад" - конец

}